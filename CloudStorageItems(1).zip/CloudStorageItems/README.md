## Cloud Storage Application

The Cloud Storage Application is a simplified cloud-based storage solution that allows users to sync files between multiple clients and a central server. It focuses on core functionalities and concurrent programming.

## Features

    File Sync: Continuous synchronization of files as changes are detected.
    Support for text and binary files of various sizes.
    Multiple file syncing for multiple clients simultaneously.
    Sync Status Monitoring: Reports the sync status of each file.
    Error Handling: Preserves data consistency in various situations, such as network failure or user errors.


## Dependencies

The Cloud Storage Application has the following dependencies:

    Java Development Kit (JDK) 8 or above.
    Java Socket API for network communication.

## Usage
	1. Clone the repository or download the source code: Start by cloning the repository to your local machine using Git, or download the source code as a ZIP file and extract it to a directory of your choice.
	
	2. Open the project in your preferred Java development environment (e.g., IntelliJ): Launch your Java IDE and import the project into the workspace. In IntelliJ, you can select "Open" and navigate to the project folder.
	
	4. Configure the server address and sync folder path in the CloudStorageApp class: Open the CloudStorageApp.java file and locate the constructor. Provide the appropriate server address and the folder path that you want to sync. For example:

'''python
CloudStorageApp cloudStorageApp = new CloudStorageApp("127.0.0.1", "C:/Users/YourUsername/SyncFolder");
'''

	4. Configure the STORAGE_FOLDER and SERVER_PORT in the CloudStorageApp class: Open the CloudStorageServer.java file. Provide the appropriate folder path (e.g "C:/Users/YourUsername/SyncFolder" ) that you want to Saved the synced folders. For example:

	
	5. Run the CloudStorageServer class to start the server: Locate the CloudStorageServer.java file in your IDE's project explorer. Right-click on it and select "Run" or use the corresponding option in your IDE's toolbar. This will start the server, and it will be ready to accept client connections.
	
	6. Run the CloudStorageApp class to start the client application: Locate the CloudStorageApp.java file in your project explorer. Right-click on it and select "Run" or use the corresponding option in your IDE's toolbar. This will start the client application and establish a connection with the server.


	7. Monitor the sync status and file transfers in the console output: The client application and server will display relevant information in the console output. You can observe the sync status of each file, file transfers happening between the client and server, and any error or status messages generated during the application's execution.
	
	8. Go to a file in the sync folder and edit it. Notice on the client console that the file is synced continously. Navigate to the Server Storage folder and locate the file you have made changes to. Notice that it has synced and the changes you made on it have been made there too. This proves that the program continously syncs files.
	
Make sure to have the server running before starting the client application to establish a connection. You can also run multiple instances of the client application on different machines or in separate IDE instances to test synchronization between multiple clients.
